# Intex
Repository for my group's coding work for our BYU IS Jr Core end of semester Intex competition. Intex is an event where we are presented with a business need and we work with data, websites, and presentations, to provide a business solution. 
